import { useEffect, useRef, useState } from 'react'
import type { FormEvent } from 'react'
import PianoRoll from './PianoRoll'

/**
 * Studio foundation batch: real local audio blobs, microphone capture, independently
 * controlled stems, IndexedDB persistence, browser-side WAV rendering, and explicit
 * server API calls for assistant/voice generation. The companion PianoRoll adds a
 * starter step sequencer rendered into audio; full MIDI export, effects, automation,
 * cloud project sync, and Suno generation remain outside this batch.
 */
type StudioTrack = { id: string; name: string; kind: 'audio' | 'recording' | 'instrument'; blob: Blob; url: string; volume: number; pan: number; muted: boolean; duration: number; start: number; waveform: number[] }
type ChatMessage = { role: 'user' | 'assistant'; content: string }
const DB_NAME = 'kus-lords-studio'
const STORE = 'projects'
const PROJECT_KEY = 'current-project-v1'

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1)
    request.onupgradeneeded = () => request.result.createObjectStore(STORE)
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error)
  })
}
async function saveProject(tracks: StudioTrack[], name: string, bpm: number) {
  const db = await openDb()
  const payload = { name, bpm, savedAt: new Date().toISOString(), tracks: tracks.map(({ id, name: trackName, kind, blob, volume, pan, muted, duration, start, waveform }) => ({ id, name: trackName, kind, blob, volume, pan, muted, duration, start, waveform })) }
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite')
    tx.objectStore(STORE).put(payload, PROJECT_KEY)
    tx.oncomplete = () => resolve()
    tx.onerror = () => reject(tx.error)
  })
  db.close()
}
async function loadProject(): Promise<{ name: string; bpm: number; tracks: Array<{ id: string; name: string; kind: 'audio' | 'recording' | 'instrument'; blob: Blob; volume: number; pan?: number; muted: boolean; duration: number; start: number; waveform?: number[] }> } | null> {
  const db = await openDb()
  const result = await new Promise<any>((resolve, reject) => {
    const request = db.transaction(STORE, 'readonly').objectStore(STORE).get(PROJECT_KEY)
    request.onsuccess = () => resolve(request.result || null)
    request.onerror = () => reject(request.error)
  })
  db.close()
  return result
}

async function decodeWaveform(blob: Blob, bars = 72): Promise<number[]> {
  const context = new AudioContext()
  try {
    const buffer = await context.decodeAudioData((await blob.arrayBuffer()).slice(0))
    const channel = buffer.getChannelData(0)
    const peaks: number[] = []
    const stride = Math.max(1, Math.floor(channel.length / bars))
    for (let bar = 0; bar < bars; bar++) {
      const start = bar * stride
      const end = Math.min(channel.length, start + stride)
      let peak = 0
      for (let i = start; i < end; i++) peak = Math.max(peak, Math.abs(channel[i]))
      peaks.push(Math.max(0.035, peak))
    }
    return peaks
  } finally { await context.close() }
}

export default function Studio() {
  const [projectName, setProjectName] = useState('Untitled Royal Session')
  const [bpm, setBpm] = useState(100)
  const [tracks, setTracks] = useState<StudioTrack[]>([])
  const [playing, setPlaying] = useState(false)
  const [position, setPosition] = useState(0)
  const [duration, setDuration] = useState(0)
  const [recording, setRecording] = useState(false)
  const [saving, setSaving] = useState(false)
  const [pianoRollOpen, setPianoRollOpen] = useState(false)
  const [status, setStatus] = useState('Your studio session is stored on this device until you choose to publish or export it.')
  const [messages, setMessages] = useState<ChatMessage[]>([{ role: 'assistant', content: 'I’m your studio assistant. Tell me the sound you want, ask for production ideas, or prepare a prompt for a connected music-generation service. Provider generation is only available when its secure API integration is configured.' }])
  const [chatInput, setChatInput] = useState('')
  const [chatBusy, setChatBusy] = useState(false)
  const [aiProvider, setAiProvider] = useState<'assistant' | 'elevenlabs' | 'suno'>('assistant')
  const recorderRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<BlobPart[]>([])
  const streamRef = useRef<MediaStream | null>(null)
  const audioRefs = useRef<Record<string, HTMLAudioElement | null>>({})
  const audioContextRef = useRef<AudioContext | null>(null)
  const audioNodesRef = useRef<Record<string, { source: MediaElementAudioSourceNode; panner: StereoPannerNode }>>({})
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [master, setMaster] = useState(0.85)
  const startTimersRef = useRef<number[]>([])
  const transportRunningRef = useRef(false)
  const playbackStartedAtRef = useRef(0)
  const playbackStartPositionRef = useRef(0)

  useEffect(() => {
    let alive = true
    loadProject().then(saved => {
      if (!alive || !saved) return
      const restored = saved.tracks.map(t => ({ ...t, pan: t.pan ?? 0, waveform: t.waveform || [], url: URL.createObjectURL(t.blob) }))
      setProjectName(saved.name || 'Untitled Royal Session'); setBpm(saved.bpm || 100); setTracks(restored)
      restored.filter(t => !t.waveform.length).forEach(t => { void decodeWaveform(t.blob).then(waveform => setTracks(prev => prev.map(item => item.id === t.id ? { ...item, waveform } : item))).catch(() => undefined) })
      setStatus(`Restored ${restored.length} track(s) from this device.`)
    }).catch(() => setStatus('Local project storage is unavailable in this browser session. You can still work and export tracks.'))
    return () => { alive = false }
  }, [])
  useEffect(() => () => { startTimersRef.current.forEach(id => window.clearTimeout(id)); streamRef.current?.getTracks().forEach(t => t.stop()); void audioContextRef.current?.close() }, [])
  useEffect(() => {
    const tick = window.setInterval(() => {
      if (!transportRunningRef.current) return
      const nextPosition = playbackStartPositionRef.current + (performance.now() - playbackStartedAtRef.current) / 1000
      setPosition(nextPosition)
      setDuration(Math.max(0, ...tracks.map(t => t.start + t.duration)))
      const currentDuration = Math.max(0, ...tracks.map(t => t.start + t.duration))
      if (currentDuration > 0 && nextPosition >= currentDuration) {
        transportRunningRef.current = false
        startTimersRef.current.forEach(id => window.clearTimeout(id)); startTimersRef.current = []
        tracks.forEach(t => audioRefs.current[t.id]?.pause())
        setPlaying(false); setPosition(currentDuration)
      } else setPlaying(true)
    }, 100)
    return () => clearInterval(tick)
  }, [tracks, duration])

  const addFiles = (files: FileList | File[]) => {
    const incoming = Array.from(files).filter(file => file.type.startsWith('audio/') || /\.(wav|mp3|flac|m4a|aac|ogg|opus)$/i.test(file.name))
    if (!incoming.length) { setStatus('Choose an audio file such as WAV, MP3, FLAC, M4A, AAC, or OGG.'); return }
    const added = incoming.map(file => ({ id: crypto.randomUUID(), name: file.name.replace(/\.[^.]+$/, ''), kind: 'audio' as const, blob: file, url: URL.createObjectURL(file), volume: 1, pan: 0, muted: false, duration: 0, start: 0, waveform: [] as number[] }))
    setTracks(prev => [...prev, ...added]); added.forEach(t => { void decodeWaveform(t.blob).then(waveform => setTracks(prev => prev.map(item => item.id === t.id ? { ...item, waveform } : item))).catch(() => setStatus(`Could not decode waveform for ${t.name}; playback and individual download may still work.`)) }); setStatus(`Imported ${added.length} audio file(s). Each file is an independently editable track.`)
  }
  const removeTrack = (id: string) => { const t = tracks.find(x => x.id === id); if (t) URL.revokeObjectURL(t.url); audioRefs.current[id]?.pause(); const route = audioNodesRef.current[id]; route?.source.disconnect(); route?.panner.disconnect(); delete audioNodesRef.current[id]; delete audioRefs.current[id]; const remaining = tracks.filter(x => x.id !== id); setTracks(remaining); setDuration(Math.max(0, ...remaining.map(x => x.start + x.duration))) }
  const toggleMute = (track: StudioTrack) => { const nextMuted = !track.muted; if (nextMuted) audioRefs.current[track.id]?.pause(); else if (transportRunningRef.current) { const audio = audioRefs.current[track.id]; if (audio) { const elapsed = playbackStartPositionRef.current + (performance.now() - playbackStartedAtRef.current) / 1000; if (elapsed >= track.start && elapsed < track.start + track.duration) { audio.currentTime = Math.max(0, elapsed - track.start); audio.volume = master * track.volume; void audio.play().catch(() => setStatus(`Playback could not resume for ${track.name}.`)) } } } updateTrack(track.id, { muted: nextMuted }) }
  const updateTrack = (id: string, patch: Partial<StudioTrack>) => setTracks(prev => prev.map(t => t.id === id ? { ...t, ...patch } : t))
  const ensureAudioRoute = (track: StudioTrack, audio: HTMLAudioElement) => {
    let context = audioContextRef.current
    if (!context) { context = new AudioContext(); audioContextRef.current = context }
    let route = audioNodesRef.current[track.id]
    if (!route) { const source = context.createMediaElementSource(audio); const panner = context.createStereoPanner(); source.connect(panner).connect(context.destination); route = { source, panner }; audioNodesRef.current[track.id] = route }
    route.panner.pan.setValueAtTime(track.pan ?? 0, context.currentTime)
    return context
  }
  const toggleTransport = async () => {
    const audios = tracks.map(t => ({ track: t, audio: audioRefs.current[t.id] })).filter((item): item is { track: StudioTrack; audio: HTMLAudioElement } => Boolean(item.audio) && !item.track.muted)
    if (!audios.length) { setStatus('Add an unmuted audio or instrument track before starting playback.'); return }
    if (transportRunningRef.current) {
      const current = playbackStartPositionRef.current + (performance.now() - playbackStartedAtRef.current) / 1000
      transportRunningRef.current = false; startTimersRef.current.forEach(id => window.clearTimeout(id)); startTimersRef.current = []
      audios.forEach(({ audio }) => audio.pause()); setPosition(current); setPlaying(false); return
    }
    const totalDuration = Math.max(0, ...tracks.map(t => t.start + t.duration))
    const time = position >= totalDuration ? 0 : position
    playbackStartPositionRef.current = time; playbackStartedAtRef.current = performance.now(); transportRunningRef.current = true
    setPosition(time); setPlaying(true)
    try { for (const { track, audio } of audios) ensureAudioRoute(track, audio); await audioContextRef.current?.resume() } catch (error) { setStatus(`Audio routing could not initialize: ${error instanceof Error ? error.message : 'browser audio error'}. Try reloading the studio.`); transportRunningRef.current = false; setPlaying(false); return }
    const results = await Promise.allSettled(audios.map(({ track, audio }) => {
      audio.pause(); audio.volume = master * track.volume
      if (time < track.start) {
        audio.currentTime = 0
        const timer = window.setTimeout(() => {
          if (transportRunningRef.current) audio.play().catch(() => setStatus(`Playback could not start for ${track.name}.`))
        }, (track.start - time) * 1000)
        startTimersRef.current.push(timer)
        return Promise.resolve()
      }
      audio.currentTime = Math.min(time - track.start, audio.duration || time - track.start)
      return audio.play()
    }))
    if (results.some(r => r.status === 'rejected')) setStatus('Playback was blocked for one or more tracks. Tap Play again to allow audio playback.')
  }
  const startRecording = async () => {
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') { setStatus('Recording is not supported by this browser. Try a current version of Chrome, Edge, or Safari with microphone permission.'); return }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      streamRef.current = stream; chunksRef.current = []
      const mime = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/webm'].find(type => MediaRecorder.isTypeSupported(type))
      const recorder = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined)
      recorderRef.current = recorder
      recorder.ondataavailable = event => { if (event.data.size) chunksRef.current.push(event.data) }
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || 'audio/webm' })
        const url = URL.createObjectURL(blob)
        const id = crypto.randomUUID()
        const track: StudioTrack = { id, name: `Recording ${new Date().toLocaleTimeString()}`, kind: 'recording', blob, url, volume: 1, pan: 0, muted: false, duration: 0, start: 0, waveform: [] }
        setTracks(prev => [...prev, track]); void decodeWaveform(blob).then(waveform => setTracks(prev => prev.map(item => item.id === id ? { ...item, waveform } : item))).catch(() => undefined); setStatus('Recording captured. Rename it, replay it, or export it as an audio file.'); stream.getTracks().forEach(t => t.stop()); streamRef.current = null
      }
      recorder.start(); setRecording(true); setStatus('Recording from your selected microphone. Keep this page open until you stop.')
    } catch (error) { setStatus(`Microphone access failed: ${error instanceof Error ? error.message : 'permission denied'}`) }
  }
  const stopRecording = () => { recorderRef.current?.stop(); setRecording(false) }
  const persist = async () => {
    setSaving(true)
    try { await saveProject(tracks, projectName, bpm); setStatus(`Saved ${tracks.length} track(s) locally on this device at ${new Date().toLocaleTimeString()}.`) }
    catch (e) { setStatus(`Could not save locally: ${e instanceof Error ? e.message : 'storage error'}. Export the project package as a backup.`) }
    finally { setSaving(false) }
  }
  const downloadTrack = (track: StudioTrack) => {
    const mime = track.blob.type.toLowerCase()
    const extension = mime.includes('mpeg') ? 'mp3' : mime.includes('wav') ? 'wav' : mime.includes('mp4') || mime.includes('aac') ? 'm4a' : mime.includes('ogg') ? 'ogg' : mime.includes('flac') ? 'flac' : 'webm'
    const a = document.createElement('a'); a.href = track.url; a.download = track.blob instanceof File ? track.blob.name : `${track.name}.${extension}`; a.click()
  }
  const exportProject = () => {
    const manifest = { app: 'Kus-Lords Music Studio', version: 1, name: projectName, bpm, exportedAt: new Date().toISOString(), note: 'This project manifest contains track metadata. Download individual audio tracks separately to preserve the audio files.', tracks: tracks.map(({ id, name, kind, volume, pan, muted, duration, start, blob }) => ({ id, name, kind, volume, pan, muted, duration, start, mimeType: blob.type, size: blob.size })) }
    const blob = new Blob([JSON.stringify(manifest, null, 2)], { type: 'application/json' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `${projectName.replace(/[^a-z0-9-_]+/gi, '-').toLowerCase() || 'kus-studio-project'}.json`; a.click(); URL.revokeObjectURL(url)
    setStatus('Downloaded the project manifest. Download each track separately to include the audio assets in your backup.')
  }
  const exportMix = async () => {
    if (!tracks.length) { setStatus('Add audio tracks before exporting a mix.'); return }
    setStatus('Rendering a mix in this browser. Large or unsupported audio files may fail; individual track downloads remain available.')
    try {
      const decoded: Array<{ track: StudioTrack; buffer: AudioBuffer }> = []
      const context = new AudioContext()
      for (const track of tracks) {
        if (track.muted) continue
        const arrayBuffer = await track.blob.arrayBuffer()
        const buffer = await context.decodeAudioData(arrayBuffer.slice(0))
        decoded.push({ track, buffer })
      }
      if (!decoded.length) throw new Error('All tracks are muted.')
      const sampleRate = Math.max(...decoded.map(item => item.buffer.sampleRate))
      const lengthSeconds = Math.max(...decoded.map(item => item.track.start + item.buffer.duration))
      const offline = new OfflineAudioContext(2, Math.ceil(lengthSeconds * sampleRate), sampleRate)
      decoded.forEach(({ track, buffer }) => { const source = offline.createBufferSource(); source.buffer = buffer; const gain = offline.createGain(); gain.gain.value = Math.max(0, Math.min(1, track.volume * master)); const panner = offline.createStereoPanner(); panner.pan.value = track.pan ?? 0; source.connect(panner).connect(gain).connect(offline.destination); source.start(Math.max(0, track.start)) })
      const rendered = await offline.startRendering()
      const wav = encodeWav(rendered)
      const url = URL.createObjectURL(wav); const a = document.createElement('a'); a.href = url; a.download = `${projectName.replace(/[^a-z0-9-_]+/gi, '-').toLowerCase() || 'kus-mix'}.wav`; a.click(); URL.revokeObjectURL(url); await context.close()
      setStatus('Mix rendered and downloaded as WAV. This basic mixer sums imported tracks and applies track/master volume; advanced effects and automation are not implemented yet.')
    } catch (e) { setStatus(`Mix export failed: ${e instanceof Error ? e.message : 'unsupported audio format'}. Download the stems individually instead.`) }
  }
  const sendChat = async (event?: FormEvent) => {
    event?.preventDefault(); const prompt = chatInput.trim(); if (!prompt || chatBusy) return
    setChatInput(''); setMessages(prev => [...prev, { role: 'user', content: prompt }]); setChatBusy(true)
    try {
      if (aiProvider === 'suno') {
        const response = await fetch('/api/studio/suno', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prompt }) })
        const body = await response.json().catch(() => ({}))
        if (!response.ok) throw new Error(body.error || 'Suno integration is not configured.')
        setMessages(prev => [...prev, { role: 'assistant', content: body.message || 'Generation request accepted by the configured provider.' }])
      } else if (aiProvider === 'elevenlabs') {
        const response = await fetch('/api/studio/elevenlabs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: prompt }) })
        if (!response.ok) { const body = await response.json().catch(() => ({})); throw new Error(body.error || 'ElevenLabs integration is not configured.') }
        const audioBlob = await response.blob(); const url = URL.createObjectURL(audioBlob); const track: StudioTrack = { id: crypto.randomUUID(), name: 'AI voice result', kind: 'audio', blob: audioBlob, url, volume: 1, pan: 0, muted: false, duration: 0, start: 0, waveform: [] }; setTracks(prev => [...prev, track]); void decodeWaveform(audioBlob).then(waveform => setTracks(prev => prev.map(item => item.id === track.id ? { ...item, waveform } : item))).catch(() => undefined); setMessages(prev => [...prev, { role: 'assistant', content: 'ElevenLabs returned audio successfully. I added it as a new studio track.' }])
      } else {
        const response = await fetch('/api/studio/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: prompt, project: { name: projectName, bpm, tracks: tracks.map(t => ({ name: t.name, kind: t.kind, duration: t.duration, muted: t.muted, volume: t.volume })) } }) })
        const body = await response.json().catch(() => ({}))
        if (!response.ok) throw new Error(body.error || 'The AI assistant API is not configured. You can still use this panel to prepare your production brief.')
        setMessages(prev => [...prev, { role: 'assistant', content: body.reply || 'No response was returned.' }])
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Request failed.'
      setMessages(prev => [...prev, { role: 'assistant', content: `${message}\n\nI have not generated or changed audio. You can still use the studio controls, and this prompt can be reused when the provider integration is configured.` }])
    } finally { setChatBusy(false) }
  }

  return <div className="studio-page">
    <header className="studio-header"><div><div className="studio-eyebrow">KUS-LORDS CREATIVE SUITE</div><h1>Music Studio <span>β</span></h1><p>A browser-based workspace for recording, arranging stems, and building your next track.</p></div><div className="studio-header-actions"><button className="studio-secondary" onClick={exportProject}>Export project</button><button className="studio-primary" onClick={persist} disabled={saving}>{saving ? 'Saving…' : 'Save session'}</button></div></header>
    <div className="studio-toolbar"><label>Project <input value={projectName} onChange={e => setProjectName(e.target.value)} /></label><label>BPM <input type="number" min={40} max={240} value={bpm} onChange={e => setBpm(Math.max(40, Math.min(240, Number(e.target.value) || 100)))} /></label><button onClick={() => fileInputRef.current?.click()}>＋ Import stems</button><button className="studio-secondary" onClick={() => setPianoRollOpen(true)}>♫ Piano roll</button><input ref={fileInputRef} type="file" accept="audio/*,.flac,.ogg,.opus" multiple hidden onChange={e => { if (e.target.files) addFiles(e.target.files); e.currentTarget.value = '' }} />{recording ? <button className="studio-danger" onClick={stopRecording}>■ Stop recording</button> : <button className="studio-secondary" onClick={startRecording}>● Record microphone</button>}<button className="studio-primary" onClick={toggleTransport}>{playing ? 'Ⅱ Pause' : '▶ Play session'}</button></div>
    <div className="studio-status">● {status}</div>
    <div className="studio-layout"><section className="studio-workspace"><div className="studio-panel-title"><div><h2>Arrangement</h2><span>{tracks.length} track(s) · {bpm} BPM</span></div><label className="master-control">Master <input type="range" min="0" max="1" step="0.01" value={master} onChange={e => { const v = Number(e.target.value); setMaster(v); tracks.forEach(t => { const audio = audioRefs.current[t.id]; if (audio) audio.volume = v * t.volume }) }} /></label></div>
      <div className="transport-scrubber"><span>{formatClock(position)}</span><input aria-label="Seek arrangement" type="range" min="0" max={Math.max(1, duration, ...tracks.map(t => t.start + t.duration))} step="0.1" value={Math.min(position, Math.max(1, duration, ...tracks.map(t => t.start + t.duration)))} onChange={e => { const next = Number(e.target.value); transportRunningRef.current = false; startTimersRef.current.forEach(id => window.clearTimeout(id)); startTimersRef.current = []; tracks.forEach(t => audioRefs.current[t.id]?.pause()); setPlaying(false); setPosition(next); playbackStartPositionRef.current = next }} /><span>{formatClock(Math.max(duration, ...tracks.map(t => t.start + t.duration)))}</span></div>
      <div className="timeline-ruler"><span>TRACK / SOURCE</span><div className="ruler-numbers">{['00:00','00:10','00:20','00:30','00:40','00:50'].map(n => <span key={n}>{n}</span>)}</div></div>
      {tracks.length === 0 ? <div className="studio-empty"><div className="studio-empty-icon">♫</div><h3>Your arrangement starts here</h3><p>Import stems or record a vocal. Each audio file becomes its own track.</p><button className="studio-primary" onClick={() => fileInputRef.current?.click()}>Import first stem</button></div> : <div className="studio-tracks">{tracks.map((track, index) => <div className={`studio-track ${track.muted ? 'is-muted' : ''}`} key={track.id}><div className="studio-track-head"><div className="track-number">{String(index + 1).padStart(2, '0')}</div><div className="track-name"><input aria-label="Track name" value={track.name} onChange={e => updateTrack(track.id, { name: e.target.value })}/><small>{track.kind === 'recording' ? 'MIC RECORDING' : track.kind === 'instrument' ? 'BUILT-IN SYNTH' : track.blob.type || 'AUDIO STEM'} · {(track.blob.size / 1048576).toFixed(1)} MB</small></div><button className="track-mini-btn" onClick={() => toggleMute(track)}>{track.muted ? 'MUTED' : 'M'}</button><button className="track-mini-btn" onClick={() => downloadTrack(track)} title="Download stem">↓</button><button className="track-mini-btn remove" onClick={() => removeTrack(track.id)} title="Remove track">×</button></div><div className="studio-track-lane"><div className="waveform-art" style={{ marginLeft: `${Math.min(92, (track.start / Math.max(60, duration)) * 100)}%`, width: `${100 - Math.min(92, (track.start / Math.max(60, duration)) * 100)}%`, opacity: track.muted ? .25 : 1 }}><div className="waveform-bars">{track.waveform.length ? track.waveform.map((peak, i) => <i key={i} style={{ height: `${Math.max(12, peak * 90)}%` }} />) : <span className="waveform-pending">{track.duration ? 'Waveform unavailable' : 'Decoding waveform…'}</span>}</div><audio ref={el => { audioRefs.current[track.id] = el }} src={track.url} preload="metadata" onLoadedMetadata={e => { const d = e.currentTarget.duration || 0; updateTrack(track.id, { duration: d }); setDuration(prev => Math.max(prev, track.start + d)) }} onPlay={e => { e.currentTarget.volume = master * track.volume }} /></div><div className="track-controls"><label>Level <input type="range" min="0" max="1" step="0.01" value={track.volume} onChange={e => { const v = Number(e.target.value); updateTrack(track.id, { volume: v }); const audio = audioRefs.current[track.id]; if (audio) audio.volume = master * v }} /></label><label>Pan <input type="range" min="-1" max="1" step="0.05" value={track.pan ?? 0} onChange={e => { const v = Number(e.target.value); updateTrack(track.id, { pan: v }); const route = audioNodesRef.current[track.id]; if (route && audioContextRef.current) route.panner.pan.setTargetAtTime(v, audioContextRef.current.currentTime, 0.015) }} /></label><label>Start (sec) <input type="number" min="0" step="0.5" value={track.start} onChange={e => updateTrack(track.id, { start: Math.max(0, Number(e.target.value) || 0) })} /></label><span>{track.duration ? `${Math.floor(track.duration / 60)}:${String(Math.floor(track.duration % 60)).padStart(2, '0')}` : 'Reading audio…'}</span></div></div></div>)}</div>}
      <div className="studio-footer-actions"><button className="studio-secondary" onClick={exportMix}>⇩ Render & download WAV mix</button><span>Basic stem summing · no effects or automation yet</span></div>
    </section>
    <aside className="studio-ai"><div className="ai-head"><div className="ai-orb">✦</div><div><h2>Studio AI</h2><span>Producer assistant</span></div><span className="ai-status-dot" title="Provider status is checked when you send a request" /></div><div className="ai-provider-label">WORKFLOW</div><select value={aiProvider} onChange={e => setAiProvider(e.target.value as typeof aiProvider)}><option value="assistant">AI production assistant</option><option value="suno">Suno music generation</option><option value="elevenlabs">ElevenLabs voice/audio</option></select><div className="provider-note">{aiProvider === 'assistant' ? 'Requires a server-side OPENAI_API_KEY.' : aiProvider === 'suno' ? 'Requires an authorized provider API and verified adapter configuration.' : 'Requires server-side ELEVENLABS_API_KEY and ELEVENLABS_VOICE_ID.'}</div><div className="ai-messages">{messages.map((m, i) => <div className={`ai-message ${m.role}`} key={i}><span>{m.role === 'assistant' ? '✦ STUDIO AI' : 'YOU'}</span><p>{m.content}</p></div>)}{chatBusy && <div className="ai-typing">Working on your request…</div>}</div><form className="ai-compose" onSubmit={sendChat}><textarea value={chatInput} onChange={e => setChatInput(e.target.value)} placeholder={aiProvider === 'suno' ? 'Describe the song you want to generate…' : aiProvider === 'elevenlabs' ? 'Write the words for a voice sample…' : 'Describe your sound or ask for production advice…'} rows={3}/><button className="studio-primary" type="submit" disabled={chatBusy || !chatInput.trim()}>{chatBusy ? 'Working…' : aiProvider === 'suno' ? 'Request generation ↗' : aiProvider === 'elevenlabs' ? 'Generate voice ↗' : 'Ask assistant ↗'}</button></form><div className="ai-footnote">No provider response is simulated. Unconfigured integrations return an explicit error.</div></aside></div>
    {pianoRollOpen && <PianoRoll bpm={bpm} onClose={() => setPianoRollOpen(false)} onRender={(blob, name, clipDuration) => { const id = crypto.randomUUID(); const track: StudioTrack = { id, name, kind: 'instrument', blob, url: URL.createObjectURL(blob), volume: 1, pan: 0, muted: false, duration: clipDuration, start: 0, waveform: [] }; setTracks(prev => [...prev, track]); setDuration(prev => Math.max(prev, clipDuration)); void decodeWaveform(blob).then(waveform => setTracks(prev => prev.map(item => item.id === id ? { ...item, waveform } : item))).catch(() => undefined); setStatus(`Rendered ${name} as a real WAV instrument clip and added it to the arrangement.`) }} />}
  </div>
}

function formatClock(seconds: number): string { const safe = Math.max(0, Number.isFinite(seconds) ? seconds : 0); return `${Math.floor(safe / 60).toString().padStart(2, '0')}:${Math.floor(safe % 60).toString().padStart(2, '0')}` }

function encodeWav(buffer: AudioBuffer): Blob {
  const channels = Math.min(2, buffer.numberOfChannels), sampleRate = buffer.sampleRate, frames = buffer.length
  const dataLength = frames * channels * 2
  const array = new ArrayBuffer(44 + dataLength); const view = new DataView(array)
  const write = (offset: number, value: string) => { for (let i = 0; i < value.length; i++) view.setUint8(offset + i, value.charCodeAt(i)) }
  write(0, 'RIFF'); view.setUint32(4, 36 + dataLength, true); write(8, 'WAVE'); write(12, 'fmt '); view.setUint32(16, 16, true); view.setUint16(20, 1, true); view.setUint16(22, channels, true); view.setUint32(24, sampleRate, true); view.setUint32(28, sampleRate * channels * 2, true); view.setUint16(32, channels * 2, true); view.setUint16(34, 16, true); write(36, 'data'); view.setUint32(40, dataLength, true)
  const channelData = Array.from({ length: channels }, (_, c) => buffer.getChannelData(c))
  let offset = 44
  for (let i = 0; i < frames; i++) for (let c = 0; c < channels; c++) { const sample = Math.max(-1, Math.min(1, channelData[c][i])); view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true); offset += 2 }
  return new Blob([array], { type: 'audio/wav' })
}
