import { useMemo, useState } from 'react'

/**
 * Studio production batch: a lightweight 16-step piano roll and built-in synth.
 * Notes are rendered to an actual WAV clip and handed to the arrangement as a
 * normal audio track. This is a usable starter sequencer, not a claim of full MIDI
 * editing/export or a substitute for a dedicated low-latency audio engine.
 */
type Props = { bpm: number; onRender: (blob: Blob, name: string, duration: number) => void; onClose: () => void }
type Note = { step: number; row: number; velocity: number }
const ROWS = [
  { label: 'C5', midi: 72 }, { label: 'B4', midi: 71 }, { label: 'A#4', midi: 70 }, { label: 'A4', midi: 69 },
  { label: 'G#4', midi: 68 }, { label: 'G4', midi: 67 }, { label: 'F#4', midi: 66 }, { label: 'F4', midi: 65 },
  { label: 'E4', midi: 64 }, { label: 'D#4', midi: 63 }, { label: 'D4', midi: 62 }, { label: 'C#4', midi: 61 }, { label: 'C4', midi: 60 },
]
const STARTER: Note[] = [
  { step: 0, row: 0, velocity: .8 }, { step: 3, row: 4, velocity: .7 }, { step: 4, row: 8, velocity: .75 },
  { step: 7, row: 5, velocity: .7 }, { step: 8, row: 2, velocity: .75 }, { step: 11, row: 6, velocity: .7 },
  { step: 12, row: 8, velocity: .75 }, { step: 14, row: 5, velocity: .7 },
]

export default function PianoRoll({ bpm, onRender, onClose }: Props) {
  const [notes, setNotes] = useState<Note[]>(STARTER)
  const [wave, setWave] = useState<'triangle' | 'sine' | 'square'>('triangle')
  const [rendering, setRendering] = useState(false)
  const [name, setName] = useState('Synth pattern')
  const duration = useMemo(() => 60 / Math.max(40, Math.min(240, bpm)) * 4, [bpm])
  const toggle = (step: number, row: number) => setNotes(current => current.some(n => n.step === step && n.row === row)
    ? current.filter(n => !(n.step === step && n.row === row))
    : [...current, { step, row, velocity: .78 }])

  const render = async () => {
    if (!notes.length) return
    setRendering(true)
    try {
      const sampleRate = 44100
      const seconds = duration
      const context = new OfflineAudioContext(2, Math.ceil(sampleRate * seconds), sampleRate)
      const stepSeconds = seconds / 16
      notes.forEach(note => {
        const osc = context.createOscillator()
        const gain = context.createGain()
        const at = note.step * stepSeconds + .005
        const noteLength = Math.min(stepSeconds * .82, seconds - at)
        if (noteLength <= 0) return
        osc.type = wave
        osc.frequency.value = 440 * Math.pow(2, (ROWS[note.row].midi - 69) / 12)
        gain.gain.setValueAtTime(.0001, at)
        gain.gain.linearRampToValueAtTime(note.velocity * .22, at + .012)
        gain.gain.setValueAtTime(note.velocity * .22, Math.max(at + .013, at + noteLength * .65))
        gain.gain.exponentialRampToValueAtTime(.0001, at + noteLength)
        osc.connect(gain).connect(context.destination)
        osc.start(at)
        osc.stop(at + noteLength + .01)
      })
      const rendered = await context.startRendering()
      const blob = encodePcmWav(rendered)
      onRender(blob, name.trim() || 'Synth pattern', seconds)
      onClose()
    } catch (error) {
      console.error('Piano roll render failed', error)
      window.alert('The browser could not render this pattern. Try a shorter session or a supported browser.')
    } finally { setRendering(false) }
  }

  return <div className="piano-modal-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose() }}>
    <section className="piano-modal" role="dialog" aria-modal="true" aria-labelledby="piano-roll-title">
      <header className="piano-head"><div><span className="studio-eyebrow">BUILT-IN INSTRUMENT</span><h2 id="piano-roll-title">Piano Roll <small>16-step sequencer</small></h2><p>Tap cells to place notes. Render the pattern into an editable arrangement audio track.</p></div><button className="studio-secondary" onClick={onClose} aria-label="Close piano roll">✕</button></header>
      <div className="piano-settings"><label>Pattern name <input value={name} onChange={e => setName(e.target.value)} /></label><label>Waveform <select value={wave} onChange={e => setWave(e.target.value as typeof wave)}><option value="triangle">Warm triangle</option><option value="sine">Pure sine</option><option value="square">Retro square</option></select></label><span>{bpm} BPM · {duration.toFixed(2)} seconds · {notes.length} notes</span></div>
      <div className="piano-grid-wrap"><div className="piano-grid"><div className="piano-corner">NOTE</div>{Array.from({ length: 16 }, (_, step) => <div key={step} className={`piano-step-label ${step % 4 === 0 ? 'bar-start' : ''}`}>{step + 1}</div>)}
        {ROWS.map((pitch, row) => <div className="piano-row-fragment" key={pitch.label} style={{ display: 'contents' }}><div className={`piano-key ${pitch.label.includes('#') ? 'black-key' : ''}`}>{pitch.label}</div>{Array.from({ length: 16 }, (_, step) => { const active = notes.some(n => n.step === step && n.row === row); return <button type="button" aria-label={`${pitch.label}, step ${step + 1}${active ? ', active' : ''}`} aria-pressed={active} key={`${pitch.label}-${step}`} onClick={() => toggle(step, row)} className={`piano-cell ${active ? 'active' : ''} ${step % 4 === 0 ? 'bar-start' : ''}`} /> })}</div>)}
      </div></div>
      <footer className="piano-footer"><button className="studio-secondary" onClick={() => setNotes([])}>Clear notes</button><button className="studio-secondary" onClick={() => setNotes(STARTER)}>Load starter pattern</button><button className="studio-primary" disabled={!notes.length || rendering} onClick={() => void render()}>{rendering ? 'Rendering audio…' : 'Render to arrangement ↗'}</button></footer>
      <p className="piano-disclaimer">This starter instrument renders audio in your browser. MIDI file export, velocity editing, automation, and external VST instruments are not included yet.</p>
    </section>
  </div>
}

function encodePcmWav(buffer: AudioBuffer): Blob {
  const channels = Math.min(2, buffer.numberOfChannels)
  const dataLength = buffer.length * channels * 2
  const array = new ArrayBuffer(44 + dataLength)
  const view = new DataView(array)
  const write = (offset: number, value: string) => { for (let i = 0; i < value.length; i++) view.setUint8(offset + i, value.charCodeAt(i)) }
  write(0, 'RIFF'); view.setUint32(4, 36 + dataLength, true); write(8, 'WAVE'); write(12, 'fmt ')
  view.setUint32(16, 16, true); view.setUint16(20, 1, true); view.setUint16(22, channels, true)
  view.setUint32(24, buffer.sampleRate, true); view.setUint32(28, buffer.sampleRate * channels * 2, true)
  view.setUint16(32, channels * 2, true); view.setUint16(34, 16, true); write(36, 'data'); view.setUint32(40, dataLength, true)
  const data = Array.from({ length: channels }, (_, channel) => buffer.getChannelData(channel))
  let offset = 44
  for (let frame = 0; frame < buffer.length; frame++) for (let channel = 0; channel < channels; channel++) {
    const sample = Math.max(-1, Math.min(1, data[channel][frame]))
    view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true); offset += 2
  }
  return new Blob([array], { type: 'audio/wav' })
}
