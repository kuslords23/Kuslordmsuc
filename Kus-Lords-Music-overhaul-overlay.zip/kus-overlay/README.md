# Kus-Lords Music

Kus-Lords Music is a music discovery and creation application. The current overhaul removes the sports experience, expands the upload form, and introduces an initial browser-based production studio.

## Current studio capabilities

- Import multiple audio stems and rename them independently.
- Record microphone audio using the browser MediaRecorder API, subject to device/browser support and microphone permission.
- Adjust track level and mute tracks.
- Save the current session locally in IndexedDB on the current device.
- Download individual audio tracks, export a project manifest, and render a basic WAV sum of imported/recorded tracks.
- Use the in-studio AI assistant when a server-side OpenAI API key is configured.
- Generate a voice sample using ElevenLabs when server-side credentials are configured.
- Suno is explicitly disabled until an authorized provider and its current API contract are selected. The app does not fake a generation result.

This is the first working foundation, not yet a full FL Studio replacement. Advanced clip splitting, MIDI/piano roll, instruments, effects, automation, mastering, cloud project sync, and a complete bundled project archive remain future work.

## Development

```bash
npm install
npm run typecheck
npm run build
npm run dev
```

## Environment configuration

Browser environment variables (safe for client use only when they are public keys):

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

Server-side Vercel environment variables:

- `OPENAI_API_KEY` and optionally `STUDIO_AI_MODEL`
- `ELEVENLABS_API_KEY`, `ELEVENLABS_VOICE_ID`, and optionally `ELEVENLABS_MODEL_ID`

Never put a Supabase service-role key or AI provider secret in a `VITE_` variable. Server-side keys must be configured in Vercel and the deployment must be rebuilt.

## Existing SCN music infrastructure

The app continues to use the existing `feed_posts` table and `kus-music` / `kus-images` storage buckets. It does not create duplicate music tables or buckets. Uploads use a user-ID-prefixed storage path to align with the existing folder ownership policy. Verify that the deployed Supabase Storage policies match this convention before production uploads.

The upload form stores release details in the existing `feed_posts` fields that are known to exist, rather than assuming additional database columns have been migrated. The current shared schema does not yet provide dedicated columns for every piece of release metadata.
