export interface Track {
  id: string
  title: string
  artist: string
  album: string
  duration: number
  audioUrl: string
  cover: string
  genre?: string
  likes?: number
}

export interface Album {
  id: string
  title: string
  artist: string
  description: string
  cover: string
  category: 'royals' | 'vibes' | 'chill' | 'afro'
  tracks: Track[]
}

const gradient = (colors: string) => `linear-gradient(135deg, ${colors})`

export const initialTracks: Track[] = [
  {
      id: 't1',
      title: 'Midnight Highway Drive',
      artist: 'Neon Coast',
      album: 'Midnight Highway',
      duration: 368,
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3',
      cover: gradient('#f857a6, #614ad2'),
      genre: 'Synthwave',
      likes: 640,
    },
  {
      id: 't2',
      title: 'Royal Crown Serenade',
      artist: 'The Velvet Shores',
      album: 'Coastal Lights & Gold',
      duration: 412,
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3',
      cover: gradient('#f5af19, #e65c00'),
      genre: 'Afro Chill',
      likes: 830,
    },
  {
      id: 't3',
      title: 'Glass Waves & Aurora',
      artist: 'Polar Nights',
      album: 'Aurora Borealis',
      duration: 291,
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3',
      cover: gradient('#00c9ff, #7b2fff'),
      genre: 'Ambient Chill',
      likes: 540,
    },
  {
      id: 't4',
      title: 'Silk City Skyline',
      artist: 'Marble Sky',
      album: 'Neo Tokyo',
      duration: 335,
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
      cover: gradient('#f6d365, #fda085'),
      genre: 'Lo-Fi Chill',
      likes: 420,
    },
  {
      id: 't5',
      title: 'Lagos to Accra Grooves',
      artist: 'Kus-Lords Allstars',
      album: 'Royal Afro Beats',
      duration: 254,
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3',
      cover: gradient('#11998e, #38ef7d'),
      genre: 'Afrobeats',
      likes: 1530,
    },
  {
      id: 't6',
      title: 'Pacific St. Drift',
      artist: 'Lush Coast',
      album: 'Pacific Waves',
      duration: 402,
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3',
      cover: gradient('#13547a, #80d0c7'),
      genre: 'Deep House',
      likes: 710,
    },
  {
      id: 't8',
      title: 'Vapor Run Horizon',
      artist: 'Chrome Pulse',
      album: 'Midnight Highway',
      duration: 356,
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-12.mp3',
      cover: gradient('#7f5fff, #ff7fff'),
      genre: 'Synthwave',
      likes: 670,
    }
]

export const albums: Album[] = [
  {
    id: 'a1', title: 'Midnight Highway', artist: 'Neon Coast',
    description: 'Late night synthwave for city drives and deep concentration.',
    cover: gradient('#f857a6, #614ad2'), category: 'vibes',
    tracks: [initialTracks[0], initialTracks[6], initialTracks[2]],
  },
  {
    id: 'a2', title: 'Royal Afro Beats', artist: 'Kus-Lords Allstars',
    description: 'High energy African rhythms and dancefloor bangers.',
    cover: gradient('#11998e, #38ef7d'), category: 'afro',
    tracks: [initialTracks[4], initialTracks[1], initialTracks[0]],
  },
  {
    id: 'a3', title: 'Kus-Lords Essentials', artist: 'Kus-Lords Artists',
    description: 'A selection of independent sounds and royal favourites.',
    cover: gradient('#e6c656, #f37335'), category: 'royals',
    tracks: [initialTracks[4], initialTracks[0], initialTracks[1], initialTracks[6]],
  },
  {
    id: 'a4', title: 'Aurora Borealis Chill', artist: 'Polar Nights',
    description: 'Ambient chill and meditative soundscapes.',
    cover: gradient('#00c9ff, #7b2fff'), category: 'chill',
    tracks: [initialTracks[2], initialTracks[3], initialTracks[5]],
  },
]

export const allTracks: Track[] = initialTracks