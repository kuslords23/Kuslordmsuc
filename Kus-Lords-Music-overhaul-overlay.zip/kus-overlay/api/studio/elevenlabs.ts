import type { VercelRequest, VercelResponse } from '@vercel/node'

/** Secure ElevenLabs text-to-speech adapter. This is voice generation, not music composition. */
export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed.' })
  const apiKey = process.env.ELEVENLABS_API_KEY
  const voiceId = process.env.ELEVENLABS_VOICE_ID
  if (!apiKey || !voiceId) return res.status(503).json({ error: 'ElevenLabs is not configured. Add ELEVENLABS_API_KEY and ELEVENLABS_VOICE_ID as server-side Vercel environment variables, then redeploy.' })
  const text = typeof req.body?.text === 'string' ? req.body.text.trim() : ''
  if (!text || text.length > 5000) return res.status(400).json({ error: 'Provide text between 1 and 5,000 characters.' })
  try {
    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}?output_format=mp3_44100_128`, {
      method: 'POST',
      headers: { 'xi-api-key': apiKey, 'Content-Type': 'application/json', Accept: 'audio/mpeg' },
      body: JSON.stringify({ text, model_id: process.env.ELEVENLABS_MODEL_ID || 'eleven_multilingual_v2' }),
    })
    if (!response.ok) {
      const detail = await response.text().catch(() => '')
      return res.status(response.status >= 500 ? 502 : response.status).json({ error: `ElevenLabs request failed (${response.status}). ${detail.slice(0, 400)}` })
    }
    const bytes = Buffer.from(await response.arrayBuffer())
    res.setHeader('Content-Type', 'audio/mpeg')
    res.setHeader('Content-Length', String(bytes.byteLength))
    res.setHeader('Cache-Control', 'no-store')
    return res.status(200).send(bytes)
  } catch {
    return res.status(502).json({ error: 'Could not reach ElevenLabs. Try again later.' })
  }
}
