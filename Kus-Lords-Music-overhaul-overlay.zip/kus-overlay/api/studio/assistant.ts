import type { VercelRequest, VercelResponse } from '@vercel/node'

/**
 * Secure server-side assistant proxy for the studio.
 * The browser never receives OPENAI_API_KEY. The route only returns an assistant reply;
 * it does not claim to generate or modify audio.
 */
export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed.' })
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: 'Studio AI is not configured. Add OPENAI_API_KEY as a server-side Vercel environment variable and redeploy.' })
  const message = typeof req.body?.message === 'string' ? req.body.message.trim() : ''
  if (!message || message.length > 6000) return res.status(400).json({ error: 'Provide a message up to 6,000 characters.' })
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: process.env.STUDIO_AI_MODEL || 'gpt-4o-mini',
        temperature: 0.7,
        messages: [
          { role: 'system', content: 'You are Kus-Lords Music Studio, a practical music production assistant. Help with arrangement, sound design, lyrics, mixing concepts, and prompts for external music generators. Do not claim to have generated or edited audio. Explain when an action must be performed in the studio or by an external provider. Keep advice clear and actionable.' },
          { role: 'user', content: `Studio context: ${JSON.stringify(req.body?.project || {})}\n\nUser request: ${message}` },
        ],
      }),
    })
    const body: any = await response.json().catch(() => ({}))
    if (!response.ok) return res.status(response.status >= 500 ? 502 : response.status).json({ error: body.error?.message || 'AI provider request failed.' })
    const reply = body.choices?.[0]?.message?.content
    if (typeof reply !== 'string' || !reply.trim()) return res.status(502).json({ error: 'AI provider returned no assistant text.' })
    return res.status(200).json({ reply })
  } catch {
    return res.status(502).json({ error: 'Could not reach the AI provider. Try again later.' })
  }
}
