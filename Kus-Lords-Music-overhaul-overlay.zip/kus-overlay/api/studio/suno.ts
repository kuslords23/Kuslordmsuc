import type { VercelRequest, VercelResponse } from '@vercel/node'

/**
 * Deliberately fail closed until a specific authorized Suno API provider and its documented
 * request/status/result contract are selected. No invented endpoint or fake generation result.
 */
export default function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed.' })
  return res.status(501).json({ error: 'Suno generation is not connected yet. Select an authorized API provider and supply its current documentation before enabling generation. No music was generated.' })
}
