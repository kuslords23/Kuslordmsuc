KUS-LORDS MUSIC OVERHAUL OVERLAY

Preferred use: apply kus-lords-music-overhaul.patch from the root of the repository using:
  git apply kus-lords-music-overhaul.patch

The patch includes additions, modifications, and deletion of the obsolete SportsSection and sports data files. Review with:
  git diff --stat
  npm install
  npm run typecheck
  npm run build

If your workspace cannot apply a patch, copy the included changed files to the same paths in the repository, then manually delete:
  src/components/SportsSection.tsx
  src/data/sports.ts

Do not copy .env values into source control. Configure AI provider secrets only as server-side Vercel environment variables.
