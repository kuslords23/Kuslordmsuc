import { useEffect, useMemo, useState } from 'react'
import type { FormEvent } from 'react'
import type { User } from '@supabase/supabase-js'
import { supabase } from '../lib/supabase'

export type AccountPage = 'profile' | 'settings'

type Preferences = {
  theme: 'dark' | 'light' | 'system'
  accent: 'pink' | 'gold' | 'blue' | 'violet'
  reduceMotion: boolean
  autoplayNext: boolean
  rememberVolume: boolean
}

const PREFS_KEY = 'kus-lords-music-preferences-v1'
const defaults: Preferences = {
  theme: 'dark',
  accent: 'pink',
  reduceMotion: false,
  autoplayNext: true,
  rememberVolume: true,
}

function loadPreferences(): Preferences {
  try {
    const stored = localStorage.getItem(PREFS_KEY)
    return stored ? { ...defaults, ...JSON.parse(stored) } : defaults
  } catch {
    return defaults
  }
}

interface ProfileSettingsProps {
  page: AccountPage
  user: User | null
  onOpenAuth: () => void
  onSignOut: () => void
  onNavigate: (page: AccountPage) => void
}

export default function ProfileSettings({ page, user, onOpenAuth, onSignOut, onNavigate }: ProfileSettingsProps) {
  const metadata = user?.user_metadata || {}
  const [fullName, setFullName] = useState(String(metadata.full_name || metadata.username || ''))
  const [username, setUsername] = useState(String(metadata.username || ''))
  const [bio, setBio] = useState(String(metadata.bio || ''))
  const [avatarUrl, setAvatarUrl] = useState(String(metadata.avatar_url || ''))
  const [website, setWebsite] = useState(String(metadata.website || ''))
  const [preferences, setPreferences] = useState<Preferences>(loadPreferences)
  const [savingProfile, setSavingProfile] = useState(false)
  const [profileMessage, setProfileMessage] = useState('')
  const [resetMessage, setResetMessage] = useState('')
  const [notificationMessage, setNotificationMessage] = useState('')

  useEffect(() => {
    // Preferences are device-local by design; they do not require a database table.
    try { localStorage.setItem(PREFS_KEY, JSON.stringify(preferences)) } catch { /* Storage may be unavailable in private browsing. */ }
    const root = document.documentElement
    root.dataset.theme = preferences.theme
    root.dataset.accent = preferences.accent
    root.classList.toggle('reduce-motion', preferences.reduceMotion)
  }, [preferences])

  useEffect(() => {
    setFullName(String(metadata.full_name || metadata.username || ''))
    setUsername(String(metadata.username || ''))
    setBio(String(metadata.bio || ''))
    setAvatarUrl(String(metadata.avatar_url || ''))
    setWebsite(String(metadata.website || ''))
  // Supabase User is replaced after authentication changes; metadata fields are the source of truth.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, user?.updated_at])

  const initials = useMemo(() => {
    const name = fullName.trim() || username.trim() || user?.email?.split('@')[0] || 'Kus-Lord'
    return name.split(/\s+/).slice(0, 2).map((part) => part[0]).join('').toUpperCase()
  }, [fullName, username, user?.email])

  const saveProfile = async (event: FormEvent) => {
    event.preventDefault()
    setProfileMessage('')
    if (!user || !supabase) {
      setProfileMessage('Sign in to save profile changes to your account.')
      return
    }
    if (avatarUrl && !/^https:\/\//i.test(avatarUrl)) {
      setProfileMessage('Profile image URL must start with https://')
      return
    }
    if (website && !/^https:\/\//i.test(website)) {
      setProfileMessage('Website URL must start with https://')
      return
    }
    setSavingProfile(true)
    const { error } = await supabase.auth.updateUser({
      data: {
        full_name: fullName.trim(),
        username: username.trim(),
        bio: bio.trim(),
        avatar_url: avatarUrl.trim(),
        website: website.trim(),
      },
    })
    setSavingProfile(false)
    setProfileMessage(error ? `Could not save profile: ${error.message}` : 'Profile saved to your account.')
  }

  const sendPasswordReset = async () => {
    setResetMessage('')
    if (!user?.email || !supabase) {
      setResetMessage('Sign in with an email account before requesting a password reset.')
      return
    }
    const { error } = await supabase.auth.resetPasswordForEmail(user.email, { redirectTo: window.location.origin })
    setResetMessage(error ? `Could not send reset email: ${error.message}` : `Password reset email requested for ${user.email}. Check your inbox.`)
  }

  const requestNotifications = async () => {
    if (!('Notification' in window)) {
      setNotificationMessage('This browser does not support notifications.')
      return
    }
    const permission = await Notification.requestPermission()
    setNotificationMessage(permission === 'granted' ? 'Browser notifications are allowed. The app will only notify you when a supported notification event is added.' : `Notification permission: ${permission}.`)
  }

  const setPref = <K extends keyof Preferences>(key: K, value: Preferences[K]) => {
    setPreferences((current) => ({ ...current, [key]: value }))
  }

  return (
    <main className="account-page tab-scroll">
      <header className="account-page-header">
        <div>
          <span className="account-eyebrow">KUS-LORDS MUSIC · ACCOUNT</span>
          <h1>{page === 'profile' ? 'Your profile' : 'Settings'}</h1>
          <p>{page === 'profile' ? 'Shape how other listeners and creators see you.' : 'Tune your listening experience and account preferences.'}</p>
        </div>
        <div className="account-page-switcher" role="group" aria-label="Account pages">
          <button className={page === 'profile' ? 'selected' : ''} type="button" onClick={() => onNavigate('profile')}>Profile</button>
          <button className={page === 'settings' ? 'selected' : ''} type="button" onClick={() => onNavigate('settings')}>Settings</button>
        </div>
      </header>

      {!user && (
        <section className="account-card account-signin-card">
          <div className="account-card-icon">♙</div>
          <div><h2>Make this space yours</h2><p>Sign in to save profile details and manage your account. Appearance preferences work on this device without signing in.</p></div>
          <button className="account-primary-btn" type="button" onClick={onOpenAuth}>Sign in</button>
        </section>
      )}

      {page === 'profile' ? (
        <form className="account-form" onSubmit={saveProfile}>
          <section className="account-card profile-identity-card">
            <div className="profile-avatar-preview">
              {avatarUrl ? <img src={avatarUrl} alt="Profile avatar preview" onError={(event) => { event.currentTarget.style.display = 'none' }} /> : <span>{initials}</span>}
            </div>
            <div className="profile-identity-copy"><h2>{fullName || username || 'Your creator profile'}</h2><p>{user?.email || 'Guest account'}{username ? ` · @${username}` : ''}</p><span className="account-muted">Your profile image is loaded from the secure HTTPS URL you provide.</span></div>
          </section>
          <section className="account-card">
            <div className="account-card-heading"><div><h2>Public profile</h2><p>These details are stored in your Supabase Auth user metadata.</p></div><span>✦</span></div>
            <div className="account-fields-grid">
              <label>Display name<input value={fullName} onChange={(event) => setFullName(event.target.value)} placeholder="Your name" maxLength={80} /></label>
              <label>Username<input value={username} onChange={(event) => setUsername(event.target.value.replace(/\s/g, '').slice(0, 30))} placeholder="creatorname" maxLength={30} /></label>
              <label className="account-field-wide">Profile image URL<input type="url" value={avatarUrl} onChange={(event) => setAvatarUrl(event.target.value)} placeholder="https://example.com/your-photo.jpg" /></label>
              <label className="account-field-wide">Website or creator link<input type="url" value={website} onChange={(event) => setWebsite(event.target.value)} placeholder="https://your-site.com" /></label>
              <label className="account-field-wide">Bio<textarea value={bio} onChange={(event) => setBio(event.target.value)} placeholder="Tell listeners what you create..." rows={4} maxLength={500} /><span className="account-character-count">{bio.length}/500</span></label>
            </div>
            <div className="account-form-footer"><span className="account-feedback" role="status">{profileMessage}</span><button className="account-primary-btn" type="submit" disabled={savingProfile || !user}>{savingProfile ? 'Saving…' : 'Save profile'}</button></div>
          </section>
          <section className="account-card">
            <div className="account-card-heading"><div><h2>Account details</h2><p>Authentication details managed by Supabase.</p></div><span>⌁</span></div>
            <div className="account-detail-row"><span>Email address</span><strong>{user?.email || 'Not signed in'}</strong></div>
            <div className="account-detail-row"><span>Account ID</span><code>{user?.id || 'Available after sign-in'}</code></div>
            {user && <div className="account-form-footer"><span className="account-muted">Need to change your password?</span><button className="account-secondary-btn" type="button" onClick={sendPasswordReset}>Send password reset email</button></div>}
            {resetMessage && <p className="account-feedback account-feedback-block" role="status">{resetMessage}</p>}
            {user && <div className="account-danger-zone"><div><strong>Sign out</strong><p>End this session on this device.</p></div><button className="account-danger-btn" type="button" onClick={onSignOut}>Sign out</button></div>}
          </section>
        </form>
      ) : (
        <div className="account-settings-layout">
          <section className="account-card">
            <div className="account-card-heading"><div><h2>Appearance</h2><p>Choose how Kus-Lords Music looks on this device.</p></div><span>◐</span></div>
            <label className="account-setting-row"><span><strong>Theme</strong><small>Use dark, light, or follow your device setting.</small></span><select value={preferences.theme} onChange={(event) => setPref('theme', event.target.value as Preferences['theme'])}><option value="dark">Dark</option><option value="light">Light</option><option value="system">System</option></select></label>
            <div className="account-setting-row"><span><strong>Accent colour</strong><small>Change highlights and active controls.</small></span><div className="accent-options" role="group" aria-label="Accent colour">{(['pink', 'gold', 'blue', 'violet'] as const).map((accent) => <button key={accent} type="button" className={`accent-choice accent-${accent} ${preferences.accent === accent ? 'chosen' : ''}`} onClick={() => setPref('accent', accent)} aria-label={`${accent} accent`} aria-pressed={preferences.accent === accent} />)}</div></div>
            <label className="account-setting-row"><span><strong>Reduce motion</strong><small>Reduce interface animation where supported.</small></span><input type="checkbox" checked={preferences.reduceMotion} onChange={(event) => setPref('reduceMotion', event.target.checked)} /></label>
          </section>
          <section className="account-card">
            <div className="account-card-heading"><div><h2>Playback</h2><p>Listening behaviour preferences.</p></div><span>♫</span></div>
            <label className="account-setting-row"><span><strong>Auto-play next track</strong><small>Continue through the current playback queue.</small></span><input type="checkbox" checked={preferences.autoplayNext} onChange={(event) => setPref('autoplayNext', event.target.checked)} /></label>
            <label className="account-setting-row"><span><strong>Remember volume</strong><small>Keep your preferred volume on this device.</small></span><input type="checkbox" checked={preferences.rememberVolume} onChange={(event) => setPref('rememberVolume', event.target.checked)} /></label>
          </section>
          <section className="account-card">
            <div className="account-card-heading"><div><h2>Notifications</h2><p>Browser permission only. Push notifications are not yet implemented.</p></div><span>♧</span></div>
            <div className="account-setting-row"><span><strong>Browser notifications</strong><small>Review or request this browser's notification permission.</small></span><button className="account-secondary-btn" type="button" onClick={requestNotifications}>Manage permission</button></div>
            {notificationMessage && <p className="account-feedback account-feedback-block" role="status">{notificationMessage}</p>}
          </section>
          <section className="account-card account-data-note"><strong>Where settings are saved</strong><p>Appearance and playback preferences are stored locally in this browser. They are not synced across devices. Profile fields are saved to your authenticated Supabase user metadata.</p><button className="account-secondary-btn" type="button" onClick={() => { setPreferences(defaults); setNotificationMessage('Preferences restored to defaults on this device.') }}>Restore defaults</button></section>
        </div>
      )}
    </main>
  )
}
