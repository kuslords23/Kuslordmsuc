# Kus-Lords Music

Kus-Lords Music is a music discovery and creation application. The current overhaul removes the sports experience, expands the upload form, and introduces an initial browser-based production studio.

## Current studio capabilities

- Import multiple audio stems and rename them independently.
- Record microphone audio using the browser MediaRecorder API, subject to device/browser support and microphone permission.
- Adjust track level and mute tracks.
- Save the current session locally in IndexedDB on the current device.
- Download individual audio tracks, export a project manifest, and render a basic WAV sum of imported/recorded tracks.
- Use the in-studio AI assistant when a server-side OpenAI API key is configured.
- Generate a voice sample using ElevenLabs when server-side credentials are configured.
- Suno is explicitly disabled until an authorized provider and its current API contract are selected. The app does not fake a generation result.

This is the first working foundation, not yet a full FL Studio replacement. Advanced clip splitting, MIDI file export, velocity editing, effects, automation, mastering, cloud project sync, and a complete bundled project archive remain future work.

## Latest implementation batch

The piano-roll sequencer is a lightweight browser synth, not a full MIDI workstation. It renders the programmed notes to a WAV clip so the resulting audio can be arranged, saved with the local session, and included in a rendered mix. Muted tracks are excluded from playback, the transport includes a seek control, and per-track stereo pan is applied during playback and WAV mix export.

## Development

```bash
npm install
npm run typecheck
npm run build
npm run dev
```

## Environment configuration

Browser environment variables (safe for client use only when they are public keys):

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

Server-side Vercel environment variables:

- `OPENAI_API_KEY` and optionally `STUDIO_AI_MODEL`
- `ELEVENLABS_API_KEY`, `ELEVENLABS_VOICE_ID`, and optionally `ELEVENLABS_MODEL_ID`

Never put a Supabase service-role key or AI provider secret in a `VITE_` variable. Server-side keys must be configured in Vercel and the deployment must be rebuilt.

## Existing SCN music infrastructure

The app continues to use the existing `feed_posts` table and `kus-music` / `kus-images` storage buckets. It does not create duplicate music tables or buckets. Uploads use a user-ID-prefixed storage path to align with the existing folder ownership policy. Verify that the deployed Supabase Storage policies match this convention before production uploads.

The upload form stores release details in the existing `feed_posts` fields that are known to exist, rather than assuming additional database columns have been migrated. The current shared schema does not yet provide dedicated columns for every piece of release metadata.


## UI availability and publishing pass (v3)
- Desktop sidebar now exposes Home, Browse, Search, Music Studio, Library, Radio, and Upload. Mobile navigation keeps the same main destinations.
- Studio controls use responsive wrapping, touch-sized targets, visible keyboard focus, and live status announcements.
- Library section tabs now switch to concrete content or an explicit explanation where a capability (playlist persistence/download history) is not implemented.
- Radio cards are keyboard-accessible buttons and do not attempt playback when no playable track exists.
- Each Studio track has a publish action that passes its audio into the existing shared-library upload form, preserving the existing SCN storage workflow.
- This batch is UI/accessibility and workflow wiring. It does not claim cloud project synchronization, playlist creation, or a complete DAW feature set.
