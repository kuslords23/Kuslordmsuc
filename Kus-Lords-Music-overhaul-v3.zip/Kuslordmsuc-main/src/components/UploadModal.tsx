import React, { useEffect, useState } from 'react'
import { User } from '@supabase/supabase-js'
import { uploadTrackToBucket } from '../lib/supabase'
import { Track } from '../data/music'

interface UploadModalProps {
  isOpen: boolean
  onClose: () => void
  user: User | null
  onTrackUploaded: (track: Track) => void
  onOpenAuth: () => void
  initialAudioFile?: File | null
}

export default function UploadModal({
  isOpen,
  onClose,
  user,
  onTrackUploaded,
  onOpenAuth,
  initialAudioFile = null,
}: UploadModalProps) {
  const [title, setTitle] = useState('')
  const [artist, setArtist] = useState('')
  const [album, setAlbum] = useState('')
  const [genre, setGenre] = useState('')
  const [description, setDescription] = useState('')
  const [releaseDate, setReleaseDate] = useState('')
  const [explicit, setExplicit] = useState(false)
  const [lyrics, setLyrics] = useState('')
  const [audioFile, setAudioFile] = useState<File | null>(null)
  const [coverFile, setCoverFile] = useState<File | null>(null)
  const [dragOver, setDragOver] = useState(false)
  const [audioPreviewUrl, setAudioPreviewUrl] = useState('')
  const [coverPreviewUrl, setCoverPreviewUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [uploadStage, setUploadStage] = useState('audio')
  const [errorMsg, setErrorMsg] = useState('')

  // Studio-originated tracks arrive as a File so the existing SCN publishing
  // workflow can be reused without a second upload/storage implementation.
  useEffect(() => {
    if (isOpen && initialAudioFile) {
      setAudioFile(initialAudioFile)
      setTitle(initialAudioFile.name.replace(/\.[^.]+$/, ''))
    }
  }, [isOpen, initialAudioFile])

  useEffect(() => {
    if (!audioFile) { setAudioPreviewUrl(''); return }
    const url = URL.createObjectURL(audioFile); setAudioPreviewUrl(url)
    return () => URL.revokeObjectURL(url)
  }, [audioFile])
  useEffect(() => {
    if (!coverFile) { setCoverPreviewUrl(''); return }
    const url = URL.createObjectURL(coverFile); setCoverPreviewUrl(url)
    return () => URL.revokeObjectURL(url)
  }, [coverFile])

  if (!isOpen) return null

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) {
      onOpenAuth()
      return
    }

    if (!audioFile) {
      setErrorMsg('Please select an audio file (MP3, WAV, FLAC, M4A).')
      return
    }

    if (!title.trim()) {
      setErrorMsg('Track title is required.')
      return
    }
    if (audioFile.size > 250 * 1024 * 1024) { setErrorMsg('Audio files must be 250 MB or smaller for this upload flow.'); return }
    if (!audioFile.type.startsWith('audio/') && !/\.(wav|mp3|flac|m4a|aac|ogg|opus)$/i.test(audioFile.name)) { setErrorMsg('This file does not look like a supported audio format.'); return }
    if (coverFile && coverFile.size > 15 * 1024 * 1024) { setErrorMsg('Cover artwork must be 15 MB or smaller.'); return }

    setLoading(true)
    setUploadProgress(0)
    setUploadStage('audio')
    setErrorMsg('')

    try {
      const track = await uploadTrackToBucket({
        title: title.trim(),
        artist: artist.trim() || user.user_metadata?.username || 'Kus-lords Artist',
        album: album.trim() || 'Singles Cloud',
        genre: genre.trim(), description: description.trim(), releaseDate, explicit, lyrics: lyrics.trim(),
        audioFile,
        coverFile,
        user,
      }, (percent, stage) => { setUploadProgress(percent); setUploadStage(stage) })

      if (track) {
        onTrackUploaded(track)
        onClose()
        setTitle('')
        setArtist('')
        setAlbum('')
        setGenre(''); setDescription(''); setReleaseDate(''); setExplicit(false); setLyrics('')
        setAudioFile(null)
        setCoverFile(null)
        setUploadProgress(0)
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to upload track.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="modal-overlay" onClick={() => { if (!loading) onClose() }}>
      <div className="modal-card upload-card" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div className="logo-mark small">☁</div>
          <h2>Publish Music</h2>
          <button className="close-btn" onClick={onClose} disabled={loading} aria-label="Close upload dialog">✕</button>
        </div>

        {!user ? (
          <div className="auth-required-box">
            <p>Sign in to upload audio and artwork to the shared music library. Supported formats depend on browser and playback support.</p>
            <button
              className="submit-btn"
              onClick={() => {
                onClose()
                onOpenAuth()
              }}
            >
              Sign In to Continue
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="auth-form">
            {errorMsg && <div className="alert error">{errorMsg}</div>}

            <div className="form-group">
              <label>Track Title *</label>
              <input
                type="text"
                required
                placeholder="Track title" maxLength={120}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label>Artist Name</label>
              <input
                type="text"
                placeholder={user.user_metadata?.username || 'Artist Name'}
                value={artist}
                onChange={(e) => setArtist(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label>Album / Collection</label>
              <input
                type="text"
                placeholder="Album or single release" maxLength={120}
                value={album}
                onChange={(e) => setAlbum(e.target.value)}
              />
            </div>

            <div className="form-row">
              <div className={`form-group audio-dropzone ${dragOver ? 'dragging' : ''}`} onDragOver={e => { e.preventDefault(); setDragOver(true) }} onDragLeave={() => setDragOver(false)} onDrop={e => { e.preventDefault(); setDragOver(false); const file = Array.from(e.dataTransfer.files).find(f => f.type.startsWith('audio/') || /\.(wav|mp3|flac|m4a|aac|ogg|opus)$/i.test(f.name)); if (file) setAudioFile(file); else setErrorMsg('Drop an audio file such as WAV, MP3, FLAC, M4A, AAC, or OGG.') }}>
                <label>Audio file *</label>
                <input type="file" accept="audio/*,.flac,.ogg,.opus" onChange={(e) => setAudioFile(e.target.files?.[0] || null)} />
                <span className="drop-hint">Drop an audio file here or tap to browse</span>
                <small>WAV, MP3, FLAC, M4A/AAC, OGG where supported. Up to 250 MB.</small>
                {audioFile && <><small>Selected: {audioFile.name} · {(audioFile.size / 1048576).toFixed(1)} MB</small>{audioPreviewUrl && <audio className="upload-audio-preview" controls preload="metadata" src={audioPreviewUrl} />}</>}
              </div>
              <div className="form-group">
                <label>Cover artwork (optional)</label>
                <input type="file" accept="image/jpeg,image/png,image/webp,image/avif" onChange={(e) => setCoverFile(e.target.files?.[0] || null)} />
                <small>JPG, PNG, WebP or AVIF. Up to 15 MB.</small>
                {coverFile && <><small>Selected: {coverFile.name}</small>{coverPreviewUrl && <img className="upload-cover-preview" src={coverPreviewUrl} alt="Selected cover artwork preview" />}</>}
              </div>
            </div>
            <div className="form-row">
              <div className="form-group"><label>Genre / style</label><input value={genre} maxLength={80} onChange={e => setGenre(e.target.value)} placeholder="e.g. Afrobeats, trap, ambient" /></div>
              <div className="form-group"><label>Release date</label><input type="date" value={releaseDate} onChange={e => setReleaseDate(e.target.value)} /></div>
            </div>
            <div className="form-group"><label>Description / credits</label><textarea rows={2} maxLength={1200} value={description} onChange={e => setDescription(e.target.value)} placeholder="Producer, featured artists, instruments, credits…" /></div>
            <div className="form-group"><label>Lyrics (optional)</label><textarea rows={3} maxLength={8000} value={lyrics} onChange={e => setLyrics(e.target.value)} placeholder="Paste lyrics if you want them associated with this release." /></div>
            <label className="upload-explicit"><input type="checkbox" checked={explicit} onChange={e => setExplicit(e.target.checked)} /> This track contains explicit content</label>

            {loading && <div className="upload-progress-wrap"><div className="upload-progress-copy"><span>{uploadStage === 'cover' ? 'Uploading cover artwork' : 'Uploading audio'}</span><strong>{uploadProgress}%</strong></div><div className="upload-progress-track"><div className="upload-progress-fill" style={{ width: `${uploadProgress}%` }} /></div><small>Progress is reported by the resumable upload client. Keep this window open until the upload completes.</small></div>}
            <button type="submit" className="submit-btn" disabled={loading}>
              {loading ? `Uploading ${uploadStage}… ${uploadProgress}%` : 'Upload & publish'}
            </button>
          </form>
        )}
      </div>
    </div>
  )
}